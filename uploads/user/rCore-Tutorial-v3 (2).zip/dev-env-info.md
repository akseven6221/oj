# rCore-Tutorial-v3
rCore-Tutorial version 3.x

## Dependency

### Binaries

* rustc: 1.57.0-nightly (e1e9319d9 2021-10-14)

* cargo-binutils: 0.3.3

* qemu: 5.0.0

* rustsbi-lib: 0.2.0-alpha.4

  rustsbi-qemu: d4968dd2

  rustsbi-k210: b689314e
